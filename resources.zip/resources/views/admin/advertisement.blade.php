 @include('admin.layouts.app')
 @yield('content')

<div class="page-wrapper">
      <div class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
          <div class="breadcrumb-title pe-3">Advertisement</div>
          <div class="ps-3">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Advertisement</li>
              </ol>
            </nav>
          </div>
        </div>
        <!--end breadcrumb-->
        
       
            <hr/>
            <div class="card border-top border-0 border-4 border-white">
              <div class="card-body p-5">
                <div class="card-title d-flex align-items-center">
                  <div><i class="bx bxs-user me-1 font-22 text-white"></i>
                  </div>
                  <h5 class="mb-0 text-white">Index Page Below Top Employes</h5>
                </div>
                <form class="row g-3">
                  <div class="col-md-6">
                    <div class="input-group mb-3">
                      <input class="form-control" type="file" id="formFile">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="input-group mb-3">
                      <input class="form-control" type="file" id="formFile">
                    </div>
                  </div>
                  <hr>

                  <div class="card-title d-flex align-items-center">
                  <div><i class="bx bxs-user me-1 font-22 text-white"></i>
                  </div>
                  <h5 class="mb-0 text-white">Index Page Below Cities</h5>
                  </div>

                 
                    <div class="col-md-6">
                      <div class="input-group mb-3">
                        <input class="form-control" type="file" id="formFile">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="input-group mb-3">
                        <input class="form-control" type="file" id="formFile">
                      </div>
                    </div>
                    <hr>


                    <div class="card-title d-flex align-items-center">
                      <div><i class="bx bxs-user me-1 font-22 text-white"></i>
                      </div>
                      <h5 class="mb-0 text-white">Dashboard Below Menu Verticle Ad</h5>
                      </div>
    
                      
                        <div class="col-md-6">
                          <div class="input-group mb-3">
                            <input class="form-control" type="file" id="formFile">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="input-group mb-3">
                            <input class="form-control" type="file" id="formFile">
                          </div>
                        </div>
                        <hr>
                        <div class="card-title d-flex align-items-center">
                          <div><i class="bx bxs-user me-1 font-22 text-white"></i>
                          </div>
                          <h5 class="mb-0 text-white">CMS Page Below Content Ad</h5>
                          </div>
        
                            <div class="col-md-6">
                              <div class="input-group mb-3">
                                <input class="form-control" type="file" id="formFile">
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="input-group mb-3">
                                <input class="form-control" type="file" id="formFile">
                              </div>
                            </div>
                            <hr>

                            <div class="card-title d-flex align-items-center">
                              <div><i class="bx bxs-user me-1 font-22 text-white"></i>
                              </div>
                              <h5 class="mb-0 text-white">Listing Page Sidebar Verticle Ad</h5>
                              </div>
            
                              
                                <div class="col-md-6">
                                  <div class="input-group mb-3">
                                    <input class="form-control" type="file" id="formFile">
                                  </div>
                                </div>
                                <div class="col-md-6">
                                  <div class="input-group mb-3">
                                    <input class="form-control" type="file" id="formFile">
                                  </div>
                                </div>
                                <hr>

                                <div class="card-title d-flex align-items-center">
                                  <div><i class="bx bxs-user me-1 font-22 text-white"></i>
                                  </div>
                                  <h5 class="mb-0 text-white">Listing Page Below Listings Horizantal Ad</h5>
                                  </div>
                
                               
                                    <div class="col-md-6">
                                      <div class="input-group mb-3">
                                        <input class="form-control" type="file" id="formFile">
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="input-group mb-3">
                                        <input class="form-control" type="file" id="formFile">
                                      </div>
                                    </div>s
                                    <hr>

                                    <div class="col">
                                      <button type="button" class="btn btn-light px-5">Update</button>
                                    </div>
                </form>
                
              </div>
            </div>




 @include('admin.layouts.footer')

 