 @include('admin.layouts.app')
 @yield('content')
 



 @include('admin.layouts.footer')
