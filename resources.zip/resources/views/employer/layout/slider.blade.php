<div class="sidebar">
        <input type="hidden" name="search" value=""/>

        <!-- Jobs By Country -->
        <div class="widget">
            <h4 class="widget-title">By Country</h4>
            <ul class="optionlist view_more_ul">
                                                                                                <li>
                    <input type="checkbox" name="country_id[]" id="country_101" value="101" >
                    <label for="country_101"></label>
                    India <span>305</span> </li>
                                                            </ul>
            <span class="text text-primary view_more hide_vm">View More</span> </div>
        <!-- Jobs By Country end--> 


        <!-- Jobs By State -->
        <div class="widget">
            <h4 class="widget-title">By State</h4>
            <ul class="optionlist view_more_ul">
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_17" value="17" >
                    <label for="state_17"></label>
                    Karnataka <span>227</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_2" value="2" >
                    <label for="state_2"></label>
                    Andhra Pradesh <span>31</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_29" value="29" >
                    <label for="state_29"></label>
                    Odisha <span>3</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_36" value="36" >
                    <label for="state_36"></label>
                    Telangana <span>6</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_22" value="22" >
                    <label for="state_22"></label>
                    Maharashtra <span>6</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_19" value="19" >
                    <label for="state_19"></label>
                    Kerala <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_35" value="35" >
                    <label for="state_35"></label>
                    Tamil Nadu <span>22</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_12" value="12" >
                    <label for="state_12"></label>
                    Gujarat <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_13" value="13" >
                    <label for="state_13"></label>
                    Haryana <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_16" value="16" >
                    <label for="state_16"></label>
                    Jharkhand <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_5" value="5" >
                    <label for="state_5"></label>
                    Bihar <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_33" value="33" >
                    <label for="state_33"></label>
                    Rajasthan <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_4" value="4" >
                    <label for="state_4"></label>
                    Assam <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="state_id[]" id="state_10" value="10" >
                    <label for="state_10"></label>
                    Delhi <span>1</span> </li>
                                                            </ul>
            <span class="text text-primary view_more hide_vm">View More</span> </div>
        <!-- Jobs By State end--> 


        <!-- Jobs By City -->
        <div class="widget">
            <h4 class="widget-title">By City</h4>
            <ul class="optionlist view_more_ul">
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1725" value="1725" >
                    <label for="city_1725"></label>
                    Mangalore <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1646" value="1646" >
                    <label for="city_1646"></label>
                    Hospet <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_285" value="285" >
                    <label for="city_285"></label>
                    Vijayawada <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1558" value="1558" >
                    <label for="city_1558"></label>
                    Bengaluru <span>160</span> </li>
                                                                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_2995" value="2995" >
                    <label for="city_2995"></label>
                    Bhubaneswar <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1684" value="1684" >
                    <label for="city_1684"></label>
                    Koppal <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_101" value="101" >
                    <label for="city_101"></label>
                    Kadiri <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1703" value="1703" >
                    <label for="city_1703"></label>
                    Kushalnagar <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1698" value="1698" >
                    <label for="city_1698"></label>
                    Kumta <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1722" value="1722" >
                    <label for="city_1722"></label>
                    Malur <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_4460" value="4460" >
                    <label for="city_4460"></label>
                    Hyderabad <span>6</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_2494" value="2494" >
                    <label for="city_2494"></label>
                    Amravati <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1892" value="1892" >
                    <label for="city_1892"></label>
                    Ernakulam <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_2707" value="2707" >
                    <label for="city_2707"></label>
                    Mumbai <span>3</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1782" value="1782" >
                    <label for="city_1782"></label>
                    Sandur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3578" value="3578" >
                    <label for="city_3578"></label>
                    Ambur <span>1</span> </li>
                                                                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1678" value="1678" >
                    <label for="city_1678"></label>
                    Kolar <span>4</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1011" value="1011" >
                    <label for="city_1011"></label>
                    Rajkot <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1113" value="1113" >
                    <label for="city_1113"></label>
                    Chita <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1827" value="1827" >
                    <label for="city_1827"></label>
                    Tumkur <span>6</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3098" value="3098" >
                    <label for="city_3098"></label>
                    Rayagada <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_176" value="176" >
                    <label for="city_176"></label>
                    Nellore <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1393" value="1393" >
                    <label for="city_1393"></label>
                    Deoghar <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_92" value="92" >
                    <label for="city_92"></label>
                    Hindupur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1757" value="1757" >
                    <label for="city_1757"></label>
                    Naregal <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_19" value="19" >
                    <label for="city_19"></label>
                    Anantapur <span>16</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1598" value="1598" >
                    <label for="city_1598"></label>
                    Dharwar <span>5</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_4341" value="4341" >
                    <label for="city_4341"></label>
                    Tuticorin <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1647" value="1647" >
                    <label for="city_1647"></label>
                    Hubli <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3659" value="3659" >
                    <label for="city_3659"></label>
                    Chennai <span>4</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1921" value="1921" >
                    <label for="city_1921"></label>
                    Kannur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1797" value="1797" >
                    <label for="city_1797"></label>
                    Shimoga <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1685" value="1685" >
                    <label for="city_1685"></label>
                    Koratagere <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_2763" value="2763" >
                    <label for="city_2763"></label>
                    Pune <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_275" value="275" >
                    <label for="city_275"></label>
                    Uravakonda <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1829" value="1829" >
                    <label for="city_1829"></label>
                    Udupi <span>4</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1605" value="1605" >
                    <label for="city_1605"></label>
                    Gangawati <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_481" value="481" >
                    <label for="city_481"></label>
                    Buxar <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_133" value="133" >
                    <label for="city_133"></label>
                    Kurnool <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1581" value="1581" >
                    <label for="city_1581"></label>
                    Chikkaballapur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1691" value="1691" >
                    <label for="city_1691"></label>
                    Krishnarajapura <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_98" value="98" >
                    <label for="city_98"></label>
                    Jammalamadugu <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_105" value="105" >
                    <label for="city_105"></label>
                    Kalyandurg <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_58" value="58" >
                    <label for="city_58"></label>
                    Cuddapah <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_63" value="63" >
                    <label for="city_63"></label>
                    Dharmavaram <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_2726" value="2726" >
                    <label for="city_2726"></label>
                    Navi Mumbai <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1701" value="1701" >
                    <label for="city_1701"></label>
                    Kunigal <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_90" value="90" >
                    <label for="city_90"></label>
                    Guntur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1579" value="1579" >
                    <label for="city_1579"></label>
                    Chickballapur <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1549" value="1549" >
                    <label for="city_1549"></label>
                    Belagula <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3912" value="3912" >
                    <label for="city_3912"></label>
                    Madurai <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_4324" value="4324" >
                    <label for="city_4324"></label>
                    Tirunelveli <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_54" value="54" >
                    <label for="city_54"></label>
                    Chittoor <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_4183" value="4183" >
                    <label for="city_4183"></label>
                    Salem <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_4026" value="4026" >
                    <label for="city_4026"></label>
                    Nazerath <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3819" value="3819" >
                    <label for="city_3819"></label>
                    Kattupakkam <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_4401" value="4401" >
                    <label for="city_4401"></label>
                    Vellore <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_4252" value="4252" >
                    <label for="city_4252"></label>
                    Tambaram <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1618" value="1618" >
                    <label for="city_1618"></label>
                    Gurmatkal <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3686" value="3686" >
                    <label for="city_3686"></label>
                    Cuddalore <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1602" value="1602" >
                    <label for="city_1602"></label>
                    Gadag <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3737" value="3737" >
                    <label for="city_3737"></label>
                    Hosur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1739" value="1739" >
                    <label for="city_1739"></label>
                    Mudigere <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1594" value="1594" >
                    <label for="city_1594"></label>
                    Davangere <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1068" value="1068" >
                    <label for="city_1068"></label>
                    Vadodara <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3683" value="3683" >
                    <label for="city_3683"></label>
                    Coimbatore <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3378" value="3378" >
                    <label for="city_3378"></label>
                    Jaipur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1775" value="1775" >
                    <label for="city_1775"></label>
                    Raybag <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1774" value="1774" >
                    <label for="city_1774"></label>
                    Ranibennur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1589" value="1589" >
                    <label for="city_1589"></label>
                    Chitradurga <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1573" value="1573" >
                    <label for="city_1573"></label>
                    Challakere <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1571" value="1571" >
                    <label for="city_1571"></label>
                    Byatarayanapura <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1583" value="1583" >
                    <label for="city_1583"></label>
                    Chiknayakanhalli <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_262" value="262" >
                    <label for="city_262"></label>
                    Tenali <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1593" value="1593" >
                    <label for="city_1593"></label>
                    Dasarahalli <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_382" value="382" >
                    <label for="city_382"></label>
                    Jorhat <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1582" value="1582" >
                    <label for="city_1582"></label>
                    Chikmagalur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3564" value="3564" >
                    <label for="city_3564"></label>
                    Alagapuri <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_266" value="266" >
                    <label for="city_266"></label>
                    Tirupati <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1726" value="1726" >
                    <label for="city_1726"></label>
                    Mangaluru <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1724" value="1724" >
                    <label for="city_1724"></label>
                    Mandya <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3551" value="3551" >
                    <label for="city_3551"></label>
                    Abiramam <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1568" value="1568" >
                    <label for="city_1568"></label>
                    Bommanahalli <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1771" value="1771" >
                    <label for="city_1771"></label>
                    Raichur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3000" value="3000" >
                    <label for="city_3000"></label>
                    Brahmapur <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_707" value="707" >
                    <label for="city_707"></label>
                    New Delhi <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1626" value="1626" >
                    <label for="city_1626"></label>
                    Haveri <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_3783" value="3783" >
                    <label for="city_3783"></label>
                    Kanchipuram <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="city_id[]" id="city_1600" value="1600" >
                    <label for="city_1600"></label>
                    Dod Ballapur <span>1</span> </li>
                                                            </ul>
            <span class="text text-primary view_more hide_vm">View More</span> </div>
        <!-- Jobs By City end--> 

        <!-- Jobs By Experience -->
        <div class="widget">
            <h4 class="widget-title">By Experience</h4>
            <ul class="optionlist view_more_ul">
                                                                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_2" value="2" >
                    <label for="job_experience_2"></label>
                    10 Year <span>6</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_4" value="4" >
                    <label for="job_experience_4"></label>
                    3 Year <span>7</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_3" value="3" >
                    <label for="job_experience_3"></label>
                    2 Year <span>6</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_5" value="5" >
                    <label for="job_experience_5"></label>
                    4 Year <span>6</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_11" value="11" >
                    <label for="job_experience_11"></label>
                    Fresher <span>24</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_9" value="9" >
                    <label for="job_experience_9"></label>
                    8 Year <span>5</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_8" value="8" >
                    <label for="job_experience_8"></label>
                    7 Year <span>6</span> </li>
                                                                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_6" value="6" >
                    <label for="job_experience_6"></label>
                    5 Year <span>4</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_12" value="12" >
                    <label for="job_experience_12"></label>
                    Less Than 1 Year <span>8</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_7" value="7" >
                    <label for="job_experience_7"></label>
                    6 Year <span>3</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_10" value="10" >
                    <label for="job_experience_10"></label>
                    9 Year <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="job_experience_id[]" id="job_experience_1" value="1" >
                    <label for="job_experience_1"></label>
                    1 Year <span>11</span> </li>
                                                            </ul>
            <span class="text text-primary view_more hide_vm">View More</span> </div>
        <!-- Jobs By Experience end --> 


        <!-- Jobs By Career Level -->
        <div class="widget">
            <h4 class="widget-title">By Career Level</h4>
            <ul class="optionlist view_more_ul">
                                                                                                                                                <li>
                    <input type="checkbox" name="career_level_id[]" id="career_level_3" value="3" >
                    <label for="career_level_3"></label>
                    Experienced Professional <span></span> </li>
                                                                                                <li>
                    <input type="checkbox" name="career_level_id[]" id="career_level_5" value="5" >
                    <label for="career_level_5"></label>
                    Intern/Student <span></span> </li>
                                                                                                <li>
                    <input type="checkbox" name="career_level_id[]" id="career_level_2" value="2" >
                    <label for="career_level_2"></label>
                    Entry Level <span></span> </li>
                                                                                                <li>
                    <input type="checkbox" name="career_level_id[]" id="career_level_1" value="1" >
                    <label for="career_level_1"></label>
                    Department Head <span></span> </li>
                                                            </ul>
            <span class="text text-primary view_more hide_vm">View More</span> </div>
        <!-- Jobs By Career Level end --> 

        <!-- Jobs By Gender -->
        <div class="widget">
            <h4 class="widget-title">By Gender</h4>
            <ul class="optionlist view_more_ul">
                                                                                                                                                <li>
                    <input type="checkbox" name="gender_id[]" id="gender_2" value="2" >
                    <label for="gender_2"></label>
                    Male <span>62</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="gender_id[]" id="gender_1" value="1" >
                    <label for="gender_1"></label>
                    Female <span>34</span> </li>
                                                            </ul>
            <span class="text text-primary view_more hide_vm">View More</span> </div>
        <!-- Jobs By Gender end --> 



        <!-- Jobs By Industry -->
        <div class="widget">
            <h4 class="widget-title">By Industry</h4>
            <ul class="optionlist view_more_ul">
                                                                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_8" value="8" >
                    <label for="industry_8"></label>
                    Accounting/Taxation <span>32</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_29" value="29" >
                    <label for="industry_29"></label>
                    Engineering <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_34" value="34" >
                    <label for="industry_34"></label>
                    BPO <span>4</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_22" value="22" >
                    <label for="industry_22"></label>
                    Business Development <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_10" value="10" >
                    <label for="industry_10"></label>
                    Manufacturing <span>4</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_24" value="24" >
                    <label for="industry_24"></label>
                    Travel/Tourism/Transportation <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_56" value="56" >
                    <label for="industry_56"></label>
                    Warehousing <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_1" value="1" >
                    <label for="industry_1"></label>
                    Information Technology <span>5</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_17" value="17" >
                    <label for="industry_17"></label>
                    Construction/Cement/Metals <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_33" value="33" >
                    <label for="industry_33"></label>
                    Architecture/Interior Design <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_3" value="3" >
                    <label for="industry_3"></label>
                    Banking/Financial Services <span>8</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_6" value="6" >
                    <label for="industry_6"></label>
                    Insurance / Takaful <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_7" value="7" >
                    <label for="industry_7"></label>
                    Advertising/PR <span>4</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_5" value="5" >
                    <label for="industry_5"></label>
                    Pharmaceuticals/Clinical Research <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_41" value="41" >
                    <label for="industry_41"></label>
                    Courier/Logistics <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_53" value="53" >
                    <label for="industry_53"></label>
                    Apparel/Clothing <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_43" value="43" >
                    <label for="industry_43"></label>
                    Recruitment/Employment Firms <span>3</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_27" value="27" >
                    <label for="industry_27"></label>
                    N.G.O./Social Services <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_13" value="13" >
                    <label for="industry_13"></label>
                    Agriculture/Fertilizer/Pesticide <span>3</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_16" value="16" >
                    <label for="industry_16"></label>
                    Mining/Oil &amp; Gas/Petroleum <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_4" value="4" >
                    <label for="industry_4"></label>
                    Fast Moving Consumer Goods (FMCG) <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_31" value="31" >
                    <label for="industry_31"></label>
                    AutoMobile <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_12" value="12" >
                    <label for="industry_12"></label>
                    Chemicals <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_25" value="25" >
                    <label for="industry_25"></label>
                    Services <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_52" value="52" >
                    <label for="industry_52"></label>
                    Investments <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_40" value="40" >
                    <label for="industry_40"></label>
                    Hospitality <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_26" value="26" >
                    <label for="industry_26"></label>
                    Retail <span>2</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_54" value="54" >
                    <label for="industry_54"></label>
                    Food &amp; Beverages <span>1</span> </li>
                                                                                                <li>
                    <input type="checkbox" name="industry_id[]" id="industry_44" value="44" >
                    <label for="industry_44"></label>
                    Real Estate/Property <span>1</span> </li>
                                                            </ul>
            <span class="text text-primary view_more hide_vm">View More</span> </div>
        <!-- Jobs By Industry end --> 

        <!-- Jobs By Skill -->
        <div class="widget">
            <h4 class="widget-title">By Skill</h4>
            <ul class="optionlist view_more_ul">
                                                                
                                <li>
                    <input type="checkbox" name="job_skill_id[]" id="job_skill_7" value="7" >
                    <label for="job_skill_7"></label>
                    English Fluency <span>4</span> </li>
                                                                
                                <li>
                    <input type="checkbox" name="job_skill_id[]" id="job_skill_18" value="18" >
                    <label for="job_skill_18"></label>
                    Strong Communication skills <span>5</span> </li>
                                                                
                                <li>
                    <input type="checkbox" name="job_skill_id[]" id="job_skill_14" value="14" >
                    <label for="job_skill_14"></label>
                    MS Office <span>5</span> </li>
                                                                
                                <li>
                    <input type="checkbox" name="job_skill_id[]" id="job_skill_5" value="5" >
                    <label for="job_skill_5"></label>
                    Communication Skills <span>5</span> </li>
                                                                
                                <li>
                    <input type="checkbox" name="job_skill_id[]" id="job_skill_13" value="13" >
                    <label for="job_skill_13"></label>
                    MS Excel <span>4</span> </li>
                                                                
                                <li>
                    <input type="checkbox" name="job_skill_id[]" id="job_skill_1" value="1" >
                    <label for="job_skill_1"></label>
                    Adobe Illustrator <span>1</span> </li>
                                                                
                                <li>
                    <input type="checkbox" name="job_skill_id[]" id="job_skill_4" value="4" >
                    <label for="job_skill_4"></label>
                    COMMUNICATION <span>1</span> </li>
                                                                
                                <li>
                    <input type="checkbox" name="job_skill_id[]" id="job_skill_15" value="15" >
                    <label for="job_skill_15"></label>
                    MySQL <span>1</span> </li>
                                                            </ul>
            <span class="text text-primary view_more hide_vm">View More</span> </div>
        <!-- Jobs By Industry end --> 


        <div class="widget">
            <h4 class="widget-title">By Functional Areas</h4>
            <ul class="optionlist view_more_ul">
                                                                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_3" value="3" >
                    <label for="functional_area_id_3"></label>
                    Admin <span>4</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_33" value="33" >
                    <label for="functional_area_id_33"></label>
                    Engineering <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_27" value="27" >
                    <label for="functional_area_id_27"></label>
                    Data Entry Operator <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_31" value="31" >
                    <label for="functional_area_id_31"></label>
                    Education &amp; Training <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_2" value="2" >
                    <label for="functional_area_id_2"></label>
                    Accounts, Finance &amp; Financial Services <span>20</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_1" value="1" >
                    <label for="functional_area_id_1"></label>
                    Accountant <span>19</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_62" value="62" >
                    <label for="functional_area_id_62"></label>
                    Logistics &amp; Warehousing <span>4</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_4" value="4" >
                    <label for="functional_area_id_4"></label>
                    Admin Operation <span>3</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_129" value="129" >
                    <label for="functional_area_id_129"></label>
                    Software Engineer <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_131" value="131" >
                    <label for="functional_area_id_131"></label>
                    Stores &amp; Warehousing <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_17" value="17" >
                    <label for="functional_area_id_17"></label>
                    Client Services &amp; Customer Support <span>3</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_12" value="12" >
                    <label for="functional_area_id_12"></label>
                    Bank Operation <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_44" value="44" >
                    <label for="functional_area_id_44"></label>
                    Health Care <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_58" value="58" >
                    <label for="functional_area_id_58"></label>
                    IT Systems Analyst <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_48" value="48" >
                    <label for="functional_area_id_48"></label>
                    HR <span>5</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_119" value="119" >
                    <label for="functional_area_id_119"></label>
                    Sales &amp; Business Development <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_5" value="5" >
                    <label for="functional_area_id_5"></label>
                    Administration <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_16" value="16" >
                    <label for="functional_area_id_16"></label>
                    Clerical <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_105" value="105" >
                    <label for="functional_area_id_105"></label>
                    Recruitment <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_6" value="6" >
                    <label for="functional_area_id_6"></label>
                    Administration Clerical <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_26" value="26" >
                    <label for="functional_area_id_26"></label>
                    Data Entry <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_102" value="102" >
                    <label for="functional_area_id_102"></label>
                    Quality Control <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_69" value="69" >
                    <label for="functional_area_id_69"></label>
                    Marketing <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_25" value="25" >
                    <label for="functional_area_id_25"></label>
                    Customer Support <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_88" value="88" >
                    <label for="functional_area_id_88"></label>
                    Procurement <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_49" value="49" >
                    <label for="functional_area_id_49"></label>
                    Human Resources <span>2</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_82" value="82" >
                    <label for="functional_area_id_82"></label>
                    Operations <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_66" value="66" >
                    <label for="functional_area_id_66"></label>
                    Managerial <span>1</span>
                </li>                
                                                                                                <li>
                    <input type="checkbox" name="functional_area_id[]" id="functional_area_id_118" value="118" >
                    <label for="functional_area_id_118"></label>
                    Sales <span>1</span>
                </li>                
                                                
            </ul>
            <!-- title end --> 
            <span class="text text-primary view_more hide_vm">View More</span> </div>


        <!-- Salary -->
        <div class="widget">
            <h4 class="widget-title">Salary Range</h4>
            <div class="form-group">
                <input class="form-control" id="current_salary" placeholder="Current Salary" name="current_salary" type="number">
            </div>
            <div class="form-group">
                <input class="form-control" id="expected_salary" placeholder="Expected Salary" name="expected_salary" type="number">
            </div>
            <div class="form-group">
                <select class="form-control" id="salary_currency" name="salary_currency"><option value="">Select Salary Currency</option><option value="AED">AED</option><option value="AF">AF</option><option value="ALL">ALL</option><option value="ANG">ANG</option><option value="ARS">ARS</option><option value="AUD">AUD</option><option value="AWG">AWG</option><option value="AZ">AZ</option><option value="BAM">BAM</option><option value="BBD">BBD</option><option value="BG">BG</option><option value="BMD">BMD</option><option value="BOB">BOB</option><option value="BRL">BRL</option><option value="BWP">BWP</option><option value="BYR">BYR</option><option value="CAD">CAD</option><option value="CHF">CHF</option><option value="CLP">CLP</option><option value="CNY">CNY</option><option value="COP">COP</option><option value="CRC">CRC</option><option value="CUP">CUP</option><option value="CZK">CZK</option><option value="DKK">DKK</option><option value="DOP ">DOP </option><option value="EGP">EGP</option><option value="EUR">EUR</option><option value="FKP">FKP</option><option value="GBP">GBP</option><option value="GHC">GHC</option><option value="GIP">GIP</option><option value="GTQ">GTQ</option><option value="GYD">GYD</option><option value="HNL">HNL</option><option value="HUF">HUF</option><option value="IDR">IDR</option><option value="ILS">ILS</option><option value="INR" selected="selected">INR</option><option value="IRR">IRR</option><option value="ISK">ISK</option><option value="JEP">JEP</option><option value="JMD">JMD</option><option value="JPY">JPY</option><option value="KGS">KGS</option><option value="KHR">KHR</option><option value="KYD">KYD</option><option value="KZT">KZT</option><option value="LAK">LAK</option><option value="LBP">LBP</option><option value="LKR">LKR</option><option value="LRD">LRD</option><option value="LTL">LTL</option><option value="LVL">LVL</option><option value="MKD">MKD</option><option value="MNT">MNT</option><option value="MUR">MUR</option><option value="MX">MX</option><option value="MYR">MYR</option><option value="MZ">MZ</option><option value="NAD">NAD</option><option value="NG">NG</option><option value="NIO">NIO</option><option value="NOK">NOK</option><option value="NPR">NPR</option><option value="NZD">NZD</option><option value="OMR">OMR</option><option value="PAB">PAB</option><option value="PE">PE</option><option value="PHP">PHP</option><option value="PKR">PKR</option><option value="PL">PL</option><option value="PYG">PYG</option><option value="QAR">QAR</option><option value="RO">RO</option><option value="RUB">RUB</option><option value="SAR">SAR</option><option value="SBD">SBD</option><option value="SCR">SCR</option><option value="SEK">SEK</option><option value="SGD">SGD</option><option value="SHP">SHP</option><option value="SRD">SRD</option><option value="SVC">SVC</option><option value="SYP">SYP</option><option value="THB">THB</option><option value="TRY">TRY</option><option value="TTD">TTD</option><option value="TVD">TVD</option><option value="TWD">TWD</option><option value="UAH">UAH</option><option value="USD">USD</option><option value="UYU">UYU</option><option value="UZS">UZS</option><option value="VEF">VEF</option><option value="VND">VND</option><option value="YER">YER</option><option value="ZAR">ZAR</option><option value="ZWD">ZWD</option></select>
            </div>
            <!-- Salary end --> 

            <!-- button -->
            <div class="searchnt">
                <button type="submit" class="btn"><i class="fa fa-search" aria-hidden="true"></i> Search</button>
            </div>
            <!-- button end--> 
        </div>
        <!-- Side Bar end --> 
    </div>
</div>                




