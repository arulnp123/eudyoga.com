
<div class="listpgWraper">

    <div class="container">
        <div class="row"> <div class="col-lg-3">
	<div class="usernavwrap">
    <ul class="usernavdash">
        <li class="active"><a href="https://eudyoga.com/company-home"><i class="fas fa-tachometer" aria-hidden="true"></i> Dashboard</a></li>
        <li class=""><a href="https://eudyoga.com/company-profile"><i class="fas fa-pencil" aria-hidden="true"></i> Edit Profile</a></li>
        <li><a href="https://eudyoga.com/company/msbp-zone-126"><i class="fas fa-user-alt" aria-hidden="true"></i> Company Public Profile</a></li>
        <li class=""><a href="https://eudyoga.com/post-job"><i class="fas fa-desktop" aria-hidden="true"></i> Post Job</a></li>
        <li class=""><a href="https://eudyoga.com/posted-jobs"><i class="fab fa-black-tie"></i> Company Jobs</a></li>

        <li class=""><a href="https://eudyoga.com/company-packages-arun"><i class="fas fa-search" aria-hidden="true"></i> CV Search Packages</a></li>
        
        <li class=""><a href="https://eudyoga.com/unloced-seekers"><i class="fas fa-user" aria-hidden="true"></i> Unlocked Users</a></li>

        <li class=""><a href="https://eudyoga.com/company-messages"><i class="fas fa-envelope" aria-hidden="true"></i> Company Messages</a></li>
        <li class=""><a href="https://eudyoga.com/company-followers"><i class="fas fa-users" aria-hidden="true"></i> Company Followers</a></li>
        <li><a href="https://eudyoga.com/company/logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-out" aria-hidden="true"></i> Logout</a>
            <form id="logout-form" action="https://eudyoga.com/company/logout" method="POST" style="display: none;"><input type="hidden" name="_token" value="BQ1p50FxaroiMMRzlSfG87rvwKGlzY9lFvP7TfQm"></form>
        </li>
    </ul>
	</div>
    <div class="row">
        <div class="col-md-12"><img src="https://eudyoga.com/public/images/banner1.jpg">.</div>
    </div>
</div>
            <div class="col-md-9 col-sm-8"> <ul class="row profilestat">
    <li class="col-md-4 col-6">
        <div class="inbox"> <i class="fas fa-clock" aria-hidden="true"></i>
            <h6><a href="https://eudyoga.com/posted-jobs">1</a></h6>
            <strong>Open Jobs</strong> </div>
    </li>
    <li class="col-md-4 col-6">
        <div class="inbox"> <i class="fas fa-user" aria-hidden="true"></i>
            <h6><a href="https://eudyoga.com/company-followers">0</a></h6>
            <strong>Followers</strong> </div>
    </li>
     <li class="col-md-4 col-6">
        <div class="inbox"> <i class="fas fa-envelope" aria-hidden="true"></i>
            <h6><a href="https://eudyoga.com/company-messages">0</a></h6>
            <strong>Messages</strong> </div>
    </li>
</ul>
        
        

        
        <div class="instoretxt">
    <div class="credit">Your Package is: <strong>Free package - INR0</strong></div>
    <div class="credit">Package Duration : <strong>14 Dec, 2023</strong> - <strong>13 Jan, 2024</strong></div>
    <div class="credit">Availed quota : <strong>0</strong> / <strong>99</strong></div>

</div>

        <div class="paypackages"> 

    <!---four-paln-->

    <div class="four-plan">

        <h3>Upgrade Package</h3>

        <div class="row"> 
            <div class="col-md-4 col-sm-6 col-xs-12">

                <ul class="boxes">

                    <li class="plan-name">Free package</li>

                    <li>

                        <div class="main-plan">
                            <div class="plan-price1-1">INR</div>
                            
                            

                            <div class="plan-price1-2">0</div>

                            <div class="clearfix"></div>

                        </div>

                    </li>

                    <li class="plan-pages">Can post jobs : 99</li>

                    <li class="plan-pages">Package Duration : 30 Days</li>

                    <li class="order paypal"><a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#buypack7" class="reqbtn">Buy Now</a></li>

                </ul>
				
				
				<div class="modal fade" id="buypack7" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		<div class="modal-body">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<i class="fas fa-times"></i>
		</button>
		<div class="invitereval">
		<h3>Please Choose Your Payment Method to Pay</h3>	
			
		<div class="totalpay">Total Amount to pay: <strong>0</strong></div>
			
		<ul class="btn2s">
								   <li class="order payu"><a href="https://eudyoga.com/payu-order-package?package_id=7&amp;type=upgrade">PayU</a></li>
				</ul>
		</div>
		</div>
		</div>
		</div>
		</div>
				

            </div>

             </div>

    </div>
